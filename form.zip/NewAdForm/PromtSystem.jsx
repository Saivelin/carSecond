import React from 'react';

const PromtSystem = () => {
	return (
		<div className='newAdForm__promtSystem'>
			<img src="/promt.png" alt="" className="newAdForm__promtSystem-image" />
			<div className="newAdForm__promtSystem-body">
				<h2>Умная сиситема промтов</h2>
				<div className="newAdForm__promtSystem-body-promts">
					<p>Срочно</p>
					<p>Срочно</p>
					<p>Срочно</p>
					<p>Срочно</p>
					<p>Срочно</p>
					<p>Срочно</p>
					<p>Срочно</p>
					<p>Срочно</p>
					<p>Ксенон</p>
					<p>Ксенон</p>
					<p>Ксенон</p>
					<p>Ксенон</p>
					<p>Ксенон</p>
					<p>Ксенон</p>
					<p>Ксенон</p>
					<p>Ксенон</p>
				</div>
				<div className='newAdForm__promtSystem-body-buttons'>
					<button className='editPromts'>Редактировать</button>
					<button className='addPromts'>+ Промты</button>
				</div>
			</div>
		</div>
	);
};

export default PromtSystem;